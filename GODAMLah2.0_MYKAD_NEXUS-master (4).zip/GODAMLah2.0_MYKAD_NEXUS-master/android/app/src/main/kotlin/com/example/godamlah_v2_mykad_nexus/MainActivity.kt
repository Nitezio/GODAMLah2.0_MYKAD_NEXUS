package com.example.godamlah_v2_mykad_nexus

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
